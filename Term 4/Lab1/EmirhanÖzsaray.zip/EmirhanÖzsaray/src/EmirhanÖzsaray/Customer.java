package EmirhanÖzsaray;

public class Customer {
	private String name;
	private int identityID;
	private Rezervation[] rezervations = new Rezervation[10];
	public Customer(String name, int identityID) {
		this.name = name;
		this.identityID = identityID;
	}

	public void makeRezervation(Hotel hotel, String roomType, int day) {
		Room array[] = hotel.getRooms();
		int i = 0;
		int j = 0;
		int isFound = 0;
		while(i < 10 && rezervations[i] != null)
			i++;
		if(i > 9)
			System.out.println("Rezervasyon Sınırına Ulastiniz.");
		else {
			while(j < 10 && array[j] != null && isFound == 0) {
				if(roomType == array[j].getRoomType() && array[j].isAvailable()) {
					rezervations[i] = new Rezervation(hotel, array[j].getRoomNumber(), day);
					array[j].setAvailable(false);
					isFound = 1;
				}
				j++;
			}
			if(isFound == 0)
				System.out.println("Sectiginiz oda tipi icin musaitlik bulunamadi.");
		}
		
	}

	public void listCustomerRezervations() {
		int i = 0;
		while(i < 10 && rezervations[i] != null) {
			System.out.println(rezervations[i].toString());
			i++;
		}
		if(i > 9)
			System.out.println("Rezervasyonunuz Yok.");
	}

	public void getInvoice(int rezervationID) {
		int i = 0;
		int isFound = 0;
		while(i < rezervations.length && isFound == 0) {
			if(rezervationID == rezervations[i].getRezervationID()) {
				System.out.println(rezervations[i].calculatePayment());
				isFound = 1;
			}
			i++;
		}
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIdentityID() {
		return identityID;
	}

	public void setIdentityID(int identityID) {
		this.identityID = identityID;
	}

	public Rezervation[] getRezervations() {
		return rezervations;
	}

	public void setRezervations(Rezervation[] rezervations) {
		this.rezervations = rezervations;
	}
	

}
