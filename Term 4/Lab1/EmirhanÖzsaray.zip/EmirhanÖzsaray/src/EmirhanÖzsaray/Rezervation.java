package EmirhanÖzsaray;

public class Rezervation {
	private static int counter = 20230001;
	private int rezervationID;
	private Hotel hotel;
	private int roomNumber;
	private int day;
	public Rezervation(Hotel hotel, int roomNumber, int day) {
		this.hotel = hotel;
		this.roomNumber = roomNumber;
		this.day = day;
		rezervationID = counter;
		counter++;
	}
	public int calculatePayment() {
		Room array[] = hotel.getRooms();
		int toplam = 0;
		int i = 0;
		while(i < array.length && toplam == 0) {
			if(roomNumber == array[i].getRoomNumber()) {
				toplam = day*(int)array[i].getPrice();
			}
			i++;
		}
		return toplam;
	}
	public int getRezervationID() {
		return rezervationID;
	}
	public void setRezervationID(int rezervationID) {
		this.rezervationID = rezervationID;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public String toString() {
		return "Rezervation [rezervationID=" + rezervationID + ", hotel=" + hotel +  ", roomNumber=" + roomNumber
				+ ", day=" + day + "]";
	}
	
}
