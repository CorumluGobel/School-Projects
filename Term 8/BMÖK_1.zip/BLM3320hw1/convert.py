import os
import cv2

def convert_pgm_to_png(directory):
    """Converts all .pgm files in the given directory to .png format."""
    if not os.path.exists(directory):
        print(f"Error: Directory '{directory}' does not exist.")
        return
    
    for filename in os.listdir(directory):
        if filename.lower().endswith(".pgm"):  # Ensure case insensitivity
            pgm_path = os.path.join(directory, filename)
            png_path = os.path.join(directory, filename.replace(".pgm", ".png"))
            
            # Read the PGM file
            img = cv2.imread(pgm_path, cv2.IMREAD_UNCHANGED)
            if img is None:
                print(f"Error: Could not read {pgm_path}")
                continue
            
            # Save as PNG
            cv2.imwrite(png_path, img)
            print(f"Converted: {pgm_path} -> {png_path}")

if __name__ == "__main__":
    directory = "./pgm_images"  # Hardcoded directory path
    convert_pgm_to_png(directory)
