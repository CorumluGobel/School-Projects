#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

typedef struct {
    int width;
    int height;
    int maxVal;
    int format;
    unsigned char **data;
} PGMImage;

unsigned char **allocate2DArray(int width, int height) {
    unsigned char **arr = (unsigned char **)malloc(height * sizeof(unsigned char *));
    if (arr == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    
    for (int i = 0; i < height; i++) {
        arr[i] = (unsigned char *)malloc(width * sizeof(unsigned char));
        if (arr[i] == NULL) {
            printf("Memory allocation failed\n");
            exit(1);
        }
    }
    
    return arr;
}

void free2DArray(unsigned char **arr, int height) {
    for (int i = 0; i < height; i++) {
        free(arr[i]);
    }
    free(arr);
}

void skipComments(FILE *fp) {
    int ch;
    char line[100];
    
    while ((ch = fgetc(fp)) != EOF && isspace(ch));
    
    if (ch == '#') {
        fgets(line, sizeof(line), fp);
        skipComments(fp);
    } else {
        fseek(fp, -1, SEEK_CUR);
    }
}

PGMImage *readPGM(const char *filename) {
    FILE *fp;
    char magic[3];
    PGMImage *img;
    int i, j;
    
    fp = fopen(filename, "rb");
    if (fp == NULL) {
        printf("Cannot open file %s\n", filename);
        return NULL;
    }
    
    img = (PGMImage *)malloc(sizeof(PGMImage));
    if (img == NULL) {
        printf("Memory allocation failed\n");
        fclose(fp);
        return NULL;
    }
    
    fgets(magic, sizeof(magic), fp);
    if (magic[0] != 'P' || (magic[1] != '2' && magic[1] != '5')) {
        printf("Invalid PGM file format\n");
        free(img);
        fclose(fp);
        return NULL;
    }
    
    img->format = magic[1] - '0';
    
    skipComments(fp);
    
    fscanf(fp, "%d %d", &img->width, &img->height);
    skipComments(fp);
    
    fscanf(fp, "%d", &img->maxVal);
    
    img->data = allocate2DArray(img->width, img->height);
    
    fgetc(fp);
    
    
    if (img->format == 2) {
        for (i = 0; i < img->height; i++) {
            for (j = 0; j < img->width; j++) {
                int pixel;
                fscanf(fp, "%d", &pixel);
                img->data[i][j] = (unsigned char)pixel;
            }
        }
    } else { 
        for (i = 0; i < img->height; i++) {
            fread(img->data[i], sizeof(unsigned char), img->width, fp);
        }
    }
    
    fclose(fp);
    return img;
}


int writePGM(const char *filename, PGMImage *img, int format) {
    FILE *fp;
    int i, j;
    
    fp = fopen(filename, "wb");
    if (fp == NULL) {
        printf("Cannot open file %s for writing\n", filename);
        return 0;
    }
    
    
    fprintf(fp, "P%d\n", format);
    fprintf(fp, "# Created by PGM file handler\n");
    fprintf(fp, "%d %d\n", img->width, img->height);
    fprintf(fp, "%d\n", img->maxVal);
    
    
    if (format == 2) {
        for (i = 0; i < img->height; i++) {
            for (j = 0; j < img->width; j++) {
                fprintf(fp, "%d ", img->data[i][j]);
                if (j % 12 == 11) fprintf(fp, "\n");
            }
            fprintf(fp, "\n");
        }
    } else {
        for (i = 0; i < img->height; i++) {
            fwrite(img->data[i], sizeof(unsigned char), img->width, fp);
        }
    }
    
    fclose(fp);
    return 1;
}

float **gaussianCalculator(float sigma, int size)
{
    float **gaussian = (float **)malloc(size * sizeof(float *));
    for (int i = 0; i < size; i++)
    {
        gaussian[i] = (float *)malloc(size * sizeof(float));
    }

    float sum = 0;
    for (int x = 0; x < size; x++)
    {
        for (int y = 0; y < size; y++)
        {
            int x1 = x - size / 2;
            int y1 = y - size / 2;
            gaussian[x][y] = exp(-(x1 * x1 + y1 * y1) / (2 * sigma * sigma)) / (2 * 3.14159 * sigma * sigma);
            sum += gaussian[x][y];
        }
    }
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            gaussian[i][j] /= sum;
        }
    }
    return gaussian;
}
unsigned char **convolution(PGMImage *out, int size, float **gaussian)
{
    int width = out->width;
    int height = out->height;
    unsigned char **data = out->data;
    unsigned char **newData = allocate2DArray(width, height);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            newData[i][j] = data[i][j];
        }
    }
    for (int i = 0 + size / 2; i < height - size / 2; i++)
    {
        for (int j = 0 + size / 2; j < width - size / 2; j++)
        {
            float sum = 0;
            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    sum += data[i + x - size / 2][j + y - size / 2] * gaussian[x][y];
                }
            }
            if(sum > 255)
            {
                sum = 255;
            }
            else if(sum < 0)
            {
                sum = 0;
            }
            newData[i][j] = (unsigned char)sum;
        }
    }
    return newData;
}
unsigned char **laplace(PGMImage *out, int size, int laplace[][3])
{
    int width = out->width;
    int height = out->height;
    unsigned char **data = out->data;
    unsigned char **newData = allocate2DArray(width, height);
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            newData[i][j] = data[i][j];
        }
    }
    for (int i = 0 + size / 2; i < height - size / 2; i++)
    {
        for (int j = 0 + size / 2; j < width - size / 2; j++)
        {
            int sum = 0;
            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    sum += data[i + x - size / 2][j + y - size / 2] * laplace[x][y];
                }
            }
            if(sum > 255)
            {
                sum = 255;
            }
            else if(sum < 0)
            {
                sum = 0;
            }
            newData[i][j] = (unsigned char)sum;
        }
    }
    return newData;
}

int main(int argc, char *argv[]) { 
    const char *inputFile = argv[1];
    const char *outputFile = argv[2];

    int laplace_one[3][3] = {{0, -1, 0}, {-1, 4, -1}, {0, -1, 0}};
    int laplace_two[3][3] = {{-1, -1, -1}, {-1, 8, -1}, {-1, -1, -1}};
    
    PGMImage *img = readPGM(inputFile);
    if (img == NULL) {
        return 1;
    }
    int outputFormat = img->format;
    
    int size = 7; //bunları 3 , 5 , 7 olarak değiştirebilirsiniz
    int sigma = 4; //bunları 1, 2, 4 olarak değiştirebilirsiniz
    float **gaussian = gaussianCalculator(sigma, size);


    //ikisinden biri yorum satırı yapılmalı
    
    //gaussian convolution
    //img->data = convolution(img, size, gaussian);

    //laplace_one ya da laplace_two
    img->data = laplace(img, 3, laplace_one);
    
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            printf("%f ", gaussian[i][j]);
        }
        printf("\n");
    }
    

    
    if (writePGM(outputFile, img, outputFormat)) {
        printf("Successfully wrote PGM file: %s in P%d format\n", outputFile, outputFormat);
    } else {
        printf("Failed to write PGM file\n");
    }
    
    free2DArray(img->data, img->height);
    free(img);
    
    return 0;
}