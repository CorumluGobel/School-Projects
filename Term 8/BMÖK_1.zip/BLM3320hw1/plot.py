import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import os
import math

def plot_pgm_from_directory(directory):
    try:
        files = [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith(".pgm")]
        num_files = len(files)
        
        if num_files == 0:
            print("No PGM files found in the directory.")
            return
        
        cols = math.ceil(math.sqrt(num_files))  # Determine number of columns
        rows = math.ceil(num_files / cols)  # Determine number of rows
        
        fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 5 * rows))
        axes = np.array(axes).reshape(-1)  # Flatten in case of 1 row
        
        for ax, file_path in zip(axes, files):
            img = Image.open(file_path)
            img_array = np.array(img)
            
            ax.imshow(img_array, cmap='gray')
            ax.axis('off')
            ax.set_title(f"PGM Image: {os.path.basename(file_path)}")
        
        # Hide any unused subplots
        for ax in axes[num_files:]:
            ax.axis("off")
        
        plt.tight_layout()
        plt.show()
    except Exception as e:
        print(f"Error: {e}")

# Example usage
plot_pgm_from_directory("./img/coins/l2")