import numpy as np
import pickle

def unpickle(file):
    with open(file, 'rb') as fo:
        data = pickle.load(fo, encoding='bytes')
    return data

def load_filtered_cifar_10_data(data_dir, selected_classes=None, train_per_class=50, test_per_class=5, negatives=False):
    # Get the meta_data_dict
    meta_data_dict = unpickle(data_dir + "/batches.meta")
    cifar_label_names = np.array([name.decode('utf-8') for name in meta_data_dict[b'label_names']])
    
    # Select classes to keep
    if selected_classes is not None:
        selected_indices = [i for i, name in enumerate(cifar_label_names) if name in selected_classes]
        cifar_label_names = cifar_label_names[selected_indices]
    else:
        selected_indices = list(range(len(cifar_label_names)))
    
    # Load all training data
    cifar_train_data = None
    cifar_train_filenames = []
    cifar_train_labels = []
    
    for i in range(1, 6):
        cifar_train_data_dict = unpickle(data_dir + "/data_batch_{}".format(i))
        if i == 1:
            cifar_train_data = cifar_train_data_dict[b'data']
        else:
            cifar_train_data = np.vstack((cifar_train_data, cifar_train_data_dict[b'data']))
        cifar_train_filenames += cifar_train_data_dict[b'filenames']
        cifar_train_labels += cifar_train_data_dict[b'labels']
    
    cifar_train_data = np.array(cifar_train_data)
    cifar_train_filenames = np.array(cifar_train_filenames)
    cifar_train_labels = np.array(cifar_train_labels)
    
    # Filter by selected classes
    train_mask = np.isin(cifar_train_labels, selected_indices)
    cifar_train_data = cifar_train_data[train_mask]
    cifar_train_filenames = cifar_train_filenames[train_mask]
    cifar_train_labels = cifar_train_labels[train_mask]
    
    # Create a mapping from original label to new index
    label_map = {old_idx: new_idx for new_idx, old_idx in enumerate(selected_indices)}
    
    # Update labels to new indices
    cifar_train_labels = np.array([label_map[label] for label in cifar_train_labels])
    
    # Load test data
    cifar_test_data_dict = unpickle(data_dir + "/test_batch")
    cifar_test_data = cifar_test_data_dict[b'data']
    cifar_test_filenames = np.array(cifar_test_data_dict[b'filenames'])
    cifar_test_labels = np.array(cifar_test_data_dict[b'labels'])
    
    # Filter test data by selected classes
    test_mask = np.isin(cifar_test_labels, selected_indices)
    cifar_test_data = cifar_test_data[test_mask]
    cifar_test_filenames = cifar_test_filenames[test_mask]
    cifar_test_labels = cifar_test_labels[test_mask]
    
    # Update test labels to new indices
    cifar_test_labels = np.array([label_map[label] for label in cifar_test_labels])
    
    # Limit number of samples per class
    train_filtered_data = []
    train_filtered_filenames = []
    train_filtered_labels = []
    
    test_filtered_data = []
    test_filtered_filenames = []
    test_filtered_labels = []
    
    # Process each class
    for new_label in range(len(selected_indices)):
        # Get indices of samples belonging to current class
        train_class_indices = np.where(cifar_train_labels == new_label)[0]
        test_class_indices = np.where(cifar_test_labels == new_label)[0]
        
        # Limit the number of samples per class
        if len(train_class_indices) > train_per_class:
            train_class_indices = train_class_indices[:train_per_class]
        
        if len(test_class_indices) > test_per_class:
            test_class_indices = test_class_indices[:test_per_class]
        
        # Add data for current class
        train_filtered_data.append(cifar_train_data[train_class_indices])
        train_filtered_filenames.append(cifar_train_filenames[train_class_indices])
        train_filtered_labels.append(cifar_train_labels[train_class_indices])
        
        test_filtered_data.append(cifar_test_data[test_class_indices])
        test_filtered_filenames.append(cifar_test_filenames[test_class_indices])
        test_filtered_labels.append(cifar_test_labels[test_class_indices])
    
    # Combine data from all classes
    cifar_train_data = np.vstack(train_filtered_data)
    cifar_train_filenames = np.concatenate(train_filtered_filenames)
    cifar_train_labels = np.concatenate(train_filtered_labels)
    
    cifar_test_data = np.vstack(test_filtered_data)
    cifar_test_filenames = np.concatenate(test_filtered_filenames)
    cifar_test_labels = np.concatenate(test_filtered_labels)
    
    # Reshape and reformat data
    cifar_train_data = cifar_train_data.reshape((len(cifar_train_data), 3, 32, 32))
    cifar_test_data = cifar_test_data.reshape((len(cifar_test_data), 3, 32, 32))
    
    if negatives:
        cifar_train_data = cifar_train_data.transpose(0, 2, 3, 1).astype(np.float32)
        cifar_test_data = cifar_test_data.transpose(0, 2, 3, 1).astype(np.float32)
    else:
        cifar_train_data = np.rollaxis(cifar_train_data, 1, 4)
        cifar_test_data = np.rollaxis(cifar_test_data, 1, 4)
    
    return cifar_train_data, cifar_train_filenames, cifar_train_labels, cifar_test_data, cifar_test_filenames, cifar_test_labels, cifar_label_names