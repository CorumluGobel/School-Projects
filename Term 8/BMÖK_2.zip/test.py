import numpy as np
import matplotlib.pyplot as plt
import pickle
from load import load_filtered_cifar_10_data


def calulcate_euclidean_distance(histogram_train, histogram_test_sample):
    
    distances = []
    for i in range(250):
        distance = 0
        for j in range(3):
            for k in range(256):
                distance += (histogram_train[i, j, k] - histogram_test_sample[j, k]) ** 2
        distances.append(np.sqrt(distance))
    return distances

if __name__ == "__main__":

    cifar_10_dir = 'cifar-10-batches-py'
    
    # Selected classes: bird, cat, dog, frog, horse
    selected_classes = ['bird', 'cat', 'dog', 'frog', 'horse']
    
    # Load the filtered data
    train_data, train_filenames, train_labels, test_data, test_filenames, test_labels, label_names = load_filtered_cifar_10_data(
        cifar_10_dir, 
        selected_classes=selected_classes,
        train_per_class=50,
        test_per_class=5
    )
    
    histograms_train = np.load("array.npy")
    histograms_test = np.zeros((250, 3, 256), dtype=np.float32)
    for i in range(25):
        for j in range(32):
            for k in range(32):
                histograms_test[i, 0, test_data[i, j, k, 0]] += 1
                histograms_test[i, 1, test_data[i, j, k, 1]] += 1
                histograms_test[i, 2, test_data[i, j, k, 2]] += 1
    # normalize
    histograms_test /= 1024

    # calculate euclidean distance
    accuracy = []
    for i in range(25):
        distances = calulcate_euclidean_distance(histograms_train, histograms_test[i])
        sorted_indices = sorted(range(len(distances)), key=lambda k: distances[k])[:5]
        min_elements = [distances[j] for j in sorted_indices]
        
        if i % 5 == 0:
            plt.figure(figsize=(15, 3))
    
        # Create subplot for current test image and its 5 closest matches
        plt.subplot(5, 6, (i % 5) * 6 + 1)
        plt.imshow(test_data[i])
        plt.title(f"Test: {label_names[test_labels[i]]}")
        plt.axis('off')
        
        # Display the 5 closest training images
        hit = False
        for j in range(5):
            plt.subplot(5, 6, (i % 5) * 6 + j + 2)
            plt.imshow(train_data[sorted_indices[j]])
            plt.title(f"{label_names[train_labels[sorted_indices[j]]]}\nDist: {min_elements[j]:.4f}")
            plt.axis('off')
            if(label_names[train_labels[sorted_indices[j]]] == label_names[test_labels[i]]):
                hit = True
        accuracy.append(hit)
        # Show the figure after processing every 5 images or the last image
        if (i + 1) % 5 == 0 or i == 24:
            acc = sum(accuracy[i-4:i+1]) / 5
            plt.subplots_adjust(hspace=0.5, wspace=0.3, top=0.85)
            plt.suptitle(f"Accuracy for batch {i//5 + 1}: {acc:.2%}", fontsize=16)
            plt.show()
    print("Final Accuracy: ", sum(accuracy) / len(accuracy))
        
    
        

        
        
        
        
        