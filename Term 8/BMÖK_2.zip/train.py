import numpy as np
import matplotlib.pyplot as plt
import pickle
from load import load_filtered_cifar_10_data

if __name__ == "__main__":
    
    cifar_10_dir = 'cifar-10-batches-py'
    
    # Selected classes: bird, cat, dog, frog, horse
    selected_classes = ['bird', 'cat', 'dog', 'frog', 'horse']
    
    # Load the filtered data
    train_data, train_filenames, train_labels, test_data, test_filenames, test_labels, label_names = load_filtered_cifar_10_data(
        cifar_10_dir, 
        selected_classes=selected_classes,
        train_per_class=50,
        test_per_class=5
    )
    
    # 250 train 3 ayrı (rgb) histogram çıkar
    histograms = np.zeros((250, 3, 256), dtype=np.float32)
    for i in range(250):
        for j in range(32):
            for k in range(32):
                histograms[i, 0, train_data[i, j, k, 0]] += 1
                histograms[i, 1, train_data[i, j, k, 1]] += 1
                histograms[i, 2, train_data[i, j, k, 2]] += 1
    # normalize
    histograms /= 1024
    np.save('array.npy', histograms)
    
