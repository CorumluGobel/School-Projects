import hashlib
import sys
from pow_create import string_to_binary, calculate_zero_bits

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: pow-check.py <powheader> <filename>")
        sys.exit(1)

    powheader = sys.argv[1]
    filename = sys.argv[2]

    with open(filename, 'r', encoding='utf-8') as file:
        file_content = file.read()
    sha = hashlib.sha256(file_content.encode('utf-8')).hexdigest()

    '''#powheader contains
        File: walrus.txt
        Initial Hash: 66efa274991ef4ab1ed1b89c06c2c8270bb73ffdc28a9002a334ec3023039945
        Proof-of-Work: $Tq{
        Hash: 00000ac3d431541152c144416f3b89d8a0df4628a2f93bb4e486418e4b3cb534
        Leading-bits: 23
        Iterations: 3789513
        Compute time: 50.429452657699585
    '''
    with open(powheader, 'r') as f:
        pow_parts = f.read().strip().split('\n')
    initial_hash = pow_parts[1].split(': ')[1].strip()
    pow_string = pow_parts[2].split(': ')[1].strip()
    final_hash = pow_parts[3].split(': ')[1].strip()
    leading_bits = int(pow_parts[4].split(': ')[1].strip())

    combined_string = pow_string + sha
    final_hash_hex = hashlib.sha256(combined_string.encode('utf-8')).hexdigest()
    final_hash_binary = string_to_binary(final_hash_hex)
    leading_bits_found = calculate_zero_bits(final_hash_binary)

    check = True
    if leading_bits_found != leading_bits:
        print("Leading bits uyuşmuyor")
        check = False
    if initial_hash != sha:
        print("Initial hash uyuşmuyor")
        check = False
    if final_hash != final_hash_hex:
        print("Hash uyuşmuyor")
        check = False
    if check:
        print("Başarılı")