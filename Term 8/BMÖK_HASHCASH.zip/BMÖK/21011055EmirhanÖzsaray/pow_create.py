import hashlib
import sys
import time

def output(filename, init_hash, pow, hash, leading, iter, time):
    print(f"File: {filename}\nInitial Hash: {init_hash}\nProof-of-Work: {pow}\nHash: {hash}\nLeading-bits: {leading}\nIterations: {iter}\nCompute time: {time}")
    
def string_to_binary(input_string):
    if not input_string:
        return ""

    binary_output = []
    for char in input_string:
        ascii_val = ord(char)
        four_bit_val = ascii_val & 0xF
        binary_str = bin(four_bit_val)[2:]
        padded_binary_str = binary_str.zfill(4)
        binary_output.append(padded_binary_str)
    return "".join(binary_output)

def calculate_zero_bits(binary_string):
    count = 0
    while count < len(binary_string) and binary_string[count] == '0':
        count += 1
    return count

def find_proof_of_work_string(initial_hash: str, target_leading_zeros: int, max_pow_length: int = 8) -> tuple[str, str, int, int] | None:
    charset = [chr(i) for i in range(33, 127)] # ASCII 33 to 126
    charset_len = len(charset)
    iterations = 0

    for length in range(1, max_pow_length + 1):
        indices = [0] * length

        while True:
            iterations += 1
            current_pow_string = ""
            for idx in indices:
                current_pow_string += charset[idx]

            combined_string = current_pow_string + initial_hash
            final_hash_hex = hashlib.sha256(combined_string.encode('utf-8')).hexdigest()
            final_hash_binary = string_to_binary(final_hash_hex)
            leading_bits_found = calculate_zero_bits(final_hash_binary)

            if leading_bits_found >= target_leading_zeros:
                return current_pow_string, final_hash_hex, leading_bits_found, iterations
            
            k = length - 1
            while k >= 0:
                if indices[k] < charset_len - 1:
                    indices[k] += 1
                    for j in range(k + 1, length):
                        indices[j] = 0
                    break
                else:
                    indices[k] = 0
                    k -= 1
            
            if k < 0:
                break
    return None
    
if __name__ == "__main__":
    time_start = time.time()
    n = len(sys.argv)
    nbits = int(sys.argv[1])
    filename = sys.argv[2]
    with open(filename, 'r', encoding='utf-8') as file:
        file_content = file.read()

    sha = hashlib.sha256(file_content.encode('utf-8')).hexdigest()

    proof_of_work, new_hash, leading, iterations = find_proof_of_work_string(sha, nbits, max_pow_length=8)
    time_end = time.time()
    output(filename, sha, proof_of_work, new_hash, leading, iterations, time_end - time_start)